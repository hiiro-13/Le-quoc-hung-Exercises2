using System.ComponentModel.DataAnnotations;

namespace LAB2_API.Models
{
    public class Product
    {
        [Key]
        public int ProductID { get; set; }
       
        public string ProductName { get; set; }
        
        public string Weight { get; set; }
     
        public int UnitPrice { get; set; }
       
        public int UnitslnStock { get; set; }
        
    }
}
using LAB2_API.Models;
using Microsoft.EntityFrameworkCore;

namespace LAB2_API.DB
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions options) : base (options) { }

         public DbSet<Product> products { get; set; }
        
    }
}
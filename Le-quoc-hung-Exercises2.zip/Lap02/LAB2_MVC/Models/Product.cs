using System.ComponentModel.DataAnnotations;

namespace LAB2_MVC.Models
{
    public class Product
    {
        [Key]
        public int productID { get; set; }
       
        public string productName { get; set; }
        
        public string weight { get; set; }
     
        public int unitPrice { get; set; }
       
        public int unitslnStock { get; set; }
    }
}
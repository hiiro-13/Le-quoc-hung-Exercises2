using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;
using LAB2_MVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace LAB2_MVC.Controllers
{
    public class ProductController : Controller

    {
        private readonly HttpClient client = null;
        private string api;

        public ProductController(){
            client = new HttpClient();
            var contentType = new MediaTypeWithQualityHeaderValue("application/json");
            client.DefaultRequestHeaders.Accept.Add(contentType);
            this.api = "https://localhost:5001/api/Product";
        }

        public async Task<IActionResult> Index(){
            HttpResponseMessage responseMessage = await client.GetAsync(api);
            string data = await responseMessage.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions{PropertyNameCaseInsensitive = true};

            List<Product> list = JsonSerializer.Deserialize<List<Product>>(data, options);
            return View(list);
        }

        public IActionResult Create(){
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateCus(Product obj){
            if(ModelState.IsValid){
                string data = JsonSerializer.Serialize(obj);
                var content = new StringContent(data, System.Text.Encoding.UTF8, "application/json");
                HttpResponseMessage requestMessage = await client.PostAsync(api, content);

                return RedirectToAction("Index");
            }
            return View(obj);
        }

        public async Task<IActionResult> Edit(int id){

            HttpResponseMessage responseMessage = await client.GetAsync(api+"/" +id);

            if(responseMessage.IsSuccessStatusCode){

                var data = responseMessage.Content.ReadAsByteArrayAsync().Result;
                var product = JsonSerializer.Deserialize<Product>(data);
                return View(product);

            }

            return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, Product obj){
            obj.productID = id;
            string data = JsonSerializer.Serialize(obj);
            var content = new StringContent(data, System.Text.Encoding.UTF8, "application/json");
            HttpResponseMessage responseMessage = await client.PutAsync(api + "/" + id, content);
            if(responseMessage.IsSuccessStatusCode){
                
                return RedirectToAction("Index");
            }
            return NotFound();
        }


        public async Task<IActionResult> Delete(int id){
            HttpResponseMessage responseMessage = await client.GetAsync(api+"/" +id);
            if(responseMessage.IsSuccessStatusCode){
                var data = responseMessage.Content.ReadAsByteArrayAsync().Result;
                var customer =JsonSerializer.Deserialize<Product>(data);
                return View(customer);
            }
            return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int id, Product obj){
            obj.productID = id;
            string data = JsonSerializer.Serialize(obj);
            var content = new StringContent(data, System.Text.Encoding.UTF8, "application/json");
            HttpResponseMessage responseMessage = await client.DeleteAsync(api + "/" + id);
            if(responseMessage.IsSuccessStatusCode){
                
                return RedirectToAction("Index");
            }
            return NotFound();
        }
        
    }
}